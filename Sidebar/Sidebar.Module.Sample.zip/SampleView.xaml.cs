﻿using System.Windows.Controls;

namespace $safeprojectname$
{
    public partial class SampleView : UserControl
    {
        public SampleView()
        {
            InitializeComponent();
        }
    }
}

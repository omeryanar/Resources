﻿using System;
using System.Runtime.Serialization;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DevExpress.Mvvm.POCO;
using Sidebar.Common;
using Sidebar.Resources;

namespace $safeprojectname$
{
    [DataContract]
    public class SampleViewModel : IModule
    {
        #region IModule

        public ImageSource Icon { get; private set; }

        public string DisplayName
        {
            get { return Properties.Resources.Sample; }
        }

        public ModuleSize Size
        {
            get { return ModuleSize.Small; }
        }

        public IModule Create()
        {
            return ViewModelSource.Create<SampleViewModel>();
        }

        #endregion

        public virtual ResourceProvider ResourceProvider { get; set; }

        public SampleViewModel()
        {
            Icon = new BitmapImage(new Uri("pack://application:,,,/$safeprojectname$;component/Assets/Sample.png", UriKind.Relative));
            ResourceProvider = new ResourceProvider(new Properties.Resources());
        }
    }
}
